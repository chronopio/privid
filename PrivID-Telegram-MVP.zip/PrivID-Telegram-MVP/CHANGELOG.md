# Changelog

## v0.1.0 - Initial Release
- Project scaffolded for Telegram + Holonym integration
- Basic structure for README, Roadmap, and Changelog created

